package clashbound;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Battle {
    private static class BattleStart {
        Enemy.type enemy;
        StartAction action;

        BattleStart(
            Enemy.type enemy,
            StartAction action
        ) {
            this.enemy = enemy;
            this.action = action;
        }
    }

    public interface StartAction {
        void run(
            Enemy.type enemy,
            Player player
        );
    }

    private static final List<BattleStart> starts =
        new ArrayList<>();

    public static void whenBattleStart(
        Enemy.type enemy,
        StartAction action
    ) {
        starts.add(
            new BattleStart(enemy, action)
        );
    }

    private static void runStartActions(
        Enemy.type enemy,
        Player player
    ) {
        for (BattleStart start : starts) {
            if (start.enemy == enemy) {
                start.action.run(enemy, player);
            }
        }
    }

    public static void start(
        Enemy.type enemy,
        Player player
    ) {
        Weapon.clear();

        runStartActions(enemy, player);

        Scanner scanner = new Scanner(System.in);

        while (enemy.isAlive && player.isAlive()) {
            System.out.println();
            System.out.println(enemy.name);
            System.out.println("HP: " + enemy.health);

            System.out.println();
            System.out.println(player.name);
            System.out.println("HP: " + player.health);
            System.out.println("Shield: " + player.shield);

            List<Weapon.Ability> choices =
                new ArrayList<>();

            System.out.println();

            int number = 1;

            for (Weapon.type weapon :
                 Weapon.getWeapons()) {

                if (weapon.isDirect()) {
                    System.out.println(
                        number + ". " +
                        weapon.name
                    );

                    choices.add(
                        weapon.getAbilities().get(0)
                    );

                    number++;
                    continue;
                }

                for (Weapon.Ability ability :
                     weapon.getAbilities()) {

                    System.out.println(
                        number + ". " +
                        weapon.name +
                        " (" +
                        ability.name +
                        ")"
                    );

                    choices.add(ability);
                    number++;
                }
            }

            if (choices.isEmpty()) {
                System.out.println(
                    "No weapons found."
                );
                return;
            }

            System.out.print("> ");

            int choice = scanner.nextInt();

            if (choice < 1 ||
                choice > choices.size()) {
                System.out.println(
                    "Invalid choice."
                );
                continue;
            }

            Weapon.Ability ability =
                choices.get(choice - 1);

            ability.action.run();

            enemy.update();

            if (!enemy.isAlive) {
                System.out.println();
                System.out.println(
                    enemy.name +
                    " was defeated!"
                );
                return;
            }

            System.out.println();
            System.out.println(
                enemy.name + " attacks!"
            );

            player.damage(10);

            System.out.println(
                "You took 10 damage."
            );

            if (!player.isAlive()) {
                System.out.println();
                System.out.println(
                    "You were defeated!"
                );
                return;
            }
        }
    }
}
