package clashbound;

import java.util.ArrayList;
import java.util.List;

public class Weapon {
    public static class type {
        public String name;

        private final List<Ability> abilities =
            new ArrayList<>();

        private boolean direct;

        public type(String name) {
            this.name = name;
        }

        public void addAbility(
            String name,
            Runnable action
        ) {
            if (name.equals("@")) {
                if (!abilities.isEmpty()) {
                    throw new IllegalArgumentException(
                        "Weapon '" + this.name +
                        "' cannot use '@' with other abilities."
                    );
                }

                direct = true;

                abilities.add(
                    new Ability(name, action)
                );

                return;
            }

            if (direct) {
                throw new IllegalArgumentException(
                    "Weapon '" + this.name +
                    "' uses '@' and cannot have other abilities."
                );
            }

            abilities.add(
                new Ability(name, action)
            );
        }

        public boolean isDirect() {
            return direct;
        }

        public List<Ability> getAbilities() {
            return abilities;
        }
    }

    public static class Ability {
        public String name;
        public Runnable action;

        public Ability(
            String name,
            Runnable action
        ) {
            this.name = name;
            this.action = action;
        }
    }

    private static final List<type> weapons =
        new ArrayList<>();

    public static type add(String name) {
        type weapon = new type(name);
        weapons.add(weapon);
        return weapon;
    }

    public static List<type> getWeapons() {
        return weapons;
    }

    public static void clear() {
        weapons.clear();
    }
}
