import clashbound.Enemy;
import clashbound.Player;
import clashbound.Battle;

import java.io.File;
import java.io.FileWriter;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    private static final File ACCOUNTS =
        new File("accounts.json");

    private static String loggedInUser;

    public static void main(String[] args) {
        System.out.println("CLASHBOUND");

        if (!login()) {
            return;
        }

        loadMods();

        if (Enemy.getEnemies().isEmpty()) {
            System.out.println();
            System.out.println("No enemies found.");
            System.out.println("Maybe add a mod?");
            return;
        }

        chooseEnemy();
    }

    private static boolean login() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println();
            System.out.println("1. Login");
            System.out.println("2. Create Account");
            System.out.println("3. Exit");
            System.out.print("> ");

            String choice = scanner.nextLine();

            if (choice.equals("1")) {
                if (doLogin(scanner)) {
                    return true;
                }
            } else if (choice.equals("2")) {
                createAccount(scanner);
            } else if (choice.equals("3")) {
                return false;
            } else {
                System.out.println("Invalid choice.");
            }
        }
    }

    private static void createAccount(
        Scanner scanner
    ) {
        System.out.println();
        System.out.print("Username: ");
        String username = scanner.nextLine();

        System.out.print("Password: ");
        String password = scanner.nextLine();

        if (username.isEmpty() ||
            password.isEmpty()) {
            System.out.println(
                "Username and password cannot be empty."
            );
            return;
        }

        if (accountExists(username)) {
            System.out.println(
                "That username already exists."
            );
            return;
        }

        try {
            String json = readAccounts();

            String entry =
                "    {\n" +
                "      \"username\": \"" +
                escape(username) +
                "\",\n" +
                "      \"password\": \"" +
                escape(password) +
                "\"\n" +
                "    }";

            if (json.contains("\"accounts\": []")) {
                json =
                    "{\n" +
                    "  \"accounts\": [\n" +
                    entry +
                    "\n  ]\n}";
            } else {
                int position =
                    json.lastIndexOf("]");

                String before =
                    json.substring(0, position)
                        .trim();

                if (before.endsWith("}")) {
                    before += ",";
                }

                json =
                    before +
                    "\n" +
                    entry +
                    "\n  ]\n}";
            }

            writeAccounts(json);

            System.out.println(
                "Account created!"
            );
        } catch (Exception e) {
            System.out.println(
                "Failed to create account."
            );
            e.printStackTrace();
        }
    }

    private static boolean doLogin(
        Scanner scanner
    ) {
        System.out.println();
        System.out.print("Username: ");
        String username = scanner.nextLine();

        System.out.print("Password: ");
        String password = scanner.nextLine();

        if (!accountExists(username, password)) {
            System.out.println(
                "Invalid username or password."
            );
            return false;
        }

        loggedInUser = username;

        System.out.println();
        System.out.println(
            "Welcome, " + username + "!"
        );

        return true;
    }

    private static boolean accountExists(
        String username
    ) {
        return accountExists(username, null);
    }

    private static boolean accountExists(
        String username,
        String password
    ) {
        try {
            String json = readAccounts();

            Pattern pattern =
                Pattern.compile(
                    "\"username\"\\s*:\\s*\"([^\"]*)\"" +
                    "\\s*,\\s*" +
                    "\"password\"\\s*:\\s*\"([^\"]*)\""
                );

            Matcher matcher =
                pattern.matcher(json);

            while (matcher.find()) {
                if (matcher.group(1).equals(username)) {
                    if (password == null) {
                        return true;
                    }

                    return matcher.group(2)
                        .equals(password);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    private static String readAccounts()
        throws Exception {

        if (!ACCOUNTS.exists()) {
            writeAccounts(
                "{\n  \"accounts\": []\n}\n"
            );
        }

        return Files.readString(
            ACCOUNTS.toPath()
        );
    }

    private static void writeAccounts(
        String json
    ) throws Exception {

        try (FileWriter writer =
                 new FileWriter(ACCOUNTS)) {
            writer.write(json);
        }
    }

    private static String escape(
        String value
    ) {
        return value
            .replace("\\", "\\\\")
            .replace("\"", "\\\"");
    }

    private static void loadMods() {
        File modsDirectory =
            new File("mods");

        if (!modsDirectory.exists() ||
            !modsDirectory.isDirectory()) {
            return;
        }

        File[] files =
            modsDirectory.listFiles();

        if (files == null) {
            return;
        }

        for (File file : files) {
            if (!file.getName().endsWith(".jar")) {
                continue;
            }

            try {
                loadMod(file);
            } catch (Exception e) {
                System.out.println(
                    "Failed to load " +
                    file.getName()
                );
                e.printStackTrace();
            }
        }
    }

    private static void loadMod(
        File file
    ) throws Exception {

        URL url =
            file.toURI().toURL();

        try (
            URLClassLoader loader =
                new URLClassLoader(
                    new URL[]{url},
                    Main.class.getClassLoader()
                )
        ) {
            Class<?> modClass =
                loader.loadClass("Main.mod");

            Object mod =
                modClass
                    .getDeclaredConstructor()
                    .newInstance();

            Method start =
                modClass.getMethod("start");

            start.invoke(mod);
        }
    }

    private static void chooseEnemy() {
        Scanner scanner = new Scanner(System.in);

        List<Enemy.type> enemies =
            Enemy.getEnemies();

        while (true) {
            System.out.println();
            System.out.println(
                "Choose an enemy:"
            );
            System.out.println();

            for (int i = 0;
                 i < enemies.size();
                 i++) {

                System.out.println(
                    (i + 1) + ". " +
                    enemies.get(i).name
                );
            }

            System.out.print("> ");

            int choice = scanner.nextInt();

            if (choice >= 1 &&
                choice <= enemies.size()) {

                Enemy.type enemy =
                    enemies.get(choice - 1);

                Player player =
                    new Player(
                        loggedInUser,
                        100
                    );

                Battle.start(
                    enemy,
                    player
                );

                return;
            }

            System.out.println(
                "Invalid choice."
            );
        }
    }
}
