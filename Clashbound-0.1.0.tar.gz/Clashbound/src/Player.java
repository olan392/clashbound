package clashbound;

public class Player {
    public int health;
    public String name;
    public int shield;

    public Player(String name, int health) {
        this.name = name;
        this.health = health;
        this.shield = 50;
    }

    public void damage(int amount) {
        if (shield > 0) {
            int shieldDamage =
                Math.min(shield, amount);

            shield -= shieldDamage;
            amount -= shieldDamage;
        }

        if (amount > 0) {
            health -= amount;
        }
    }

    public boolean isAlive() {
        return health > 0;
    }
}
