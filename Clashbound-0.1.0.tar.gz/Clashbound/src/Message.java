package clashbound;

import java.util.HashMap;
import java.util.Map;

public class Message {
    private static final Map<String, String> messages =
        new HashMap<>();

    private static String current;

    public static void add(String name) {
        messages.put(name, "");
    }

    public static void setText(
        String name,
        String text
    ) {
        if (!messages.containsKey(name)) {
            throw new IllegalArgumentException(
                "Message '" + name + "' does not exist."
            );
        }

        messages.put(name, text);
    }

    public static void setup(String name) {
        if (!messages.containsKey(name)) {
            throw new IllegalArgumentException(
                "Message '" + name + "' does not exist."
            );
        }

        current = name;
    }

    public static void show() {
        if (current == null) {
            throw new IllegalStateException(
                "No message has been setup."
            );
        }

        System.out.println(
            messages.get(current)
        );
    }
}
