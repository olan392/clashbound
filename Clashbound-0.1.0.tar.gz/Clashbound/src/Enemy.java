package clashbound;

import java.util.ArrayList;
import java.util.List;

public class Enemy {
    public static class type {
        public int health;
        public String name;
        public boolean isAlive;

        public type(String name, int health) {
            this.name = name;
            this.health = health;
            this.isAlive = true;
        }

        public void update() {
            isAlive = health > 0;
        }
    }

    private static final List<type> enemies =
        new ArrayList<>();

    public static type add(String name, int health) {
        type enemy = new type(name, health);
        enemies.add(enemy);
        return enemy;
    }

    public static List<type> getEnemies() {
        return enemies;
    }
}
